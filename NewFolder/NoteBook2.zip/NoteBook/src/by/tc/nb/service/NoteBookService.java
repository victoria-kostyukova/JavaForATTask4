package by.tc.nb.service;

import java.util.Date;

import by.tc.nb.service.exception.ServiceException;

public interface NoteBookService {
	
	void addNote(String note, Date date) throws ServiceException;

}

package by.tc.nb.dao.exception;

public class DAOException extends Exception {

}

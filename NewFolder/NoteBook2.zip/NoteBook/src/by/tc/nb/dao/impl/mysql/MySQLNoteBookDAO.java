package by.tc.nb.dao.impl.mysql;

import by.tc.nb.bean.entity.Note;
import by.tc.nb.dao.NoteBookDAO;

public class MySQLNoteBookDAO implements NoteBookDAO{

	@Override
	public void addNote(Note note) {
		// TODO Auto-generated method stub
		
	}

}

package by.tc.nb.dao;

import by.tc.nb.bean.entity.Note;

public interface NoteBookDAO {
	
	void addNote(Note note);

}

package by.tc.nb.command.impl;

import by.tc.nb.bean.Request;
import by.tc.nb.bean.Response;
import by.tc.nb.command.Command;

public class FindNotes implements Command{

	@Override
	public Response execute(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

}

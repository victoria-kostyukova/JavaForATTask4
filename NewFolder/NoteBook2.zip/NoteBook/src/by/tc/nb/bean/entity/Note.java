package by.tc.nb.bean.entity;

public class Note {

}

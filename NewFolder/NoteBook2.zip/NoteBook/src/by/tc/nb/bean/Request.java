package by.tc.nb.bean;

public class Request {
	private String commandName;

	public String getCommandName() {
		return commandName;
	}

	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}
	
	

}

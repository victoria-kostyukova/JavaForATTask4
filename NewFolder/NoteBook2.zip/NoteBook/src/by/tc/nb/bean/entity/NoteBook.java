package by.tc.nb.bean.entity;

import java.util.List;

public class NoteBook {
	
	List<Note> notes;

}

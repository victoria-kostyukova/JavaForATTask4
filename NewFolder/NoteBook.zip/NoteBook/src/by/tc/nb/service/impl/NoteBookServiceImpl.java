package by.tc.nb.service.impl;

import java.util.Date;

import by.tc.nb.bean.entity.Note;
import by.tc.nb.bean.entity.NoteBook;
import by.tc.nb.service.NoteBookService;
import by.tc.nb.service.exception.ServiceException;
import by.tc.nb.source.NoteBookProvider;

public class NoteBookServiceImpl implements NoteBookService {

	@Override
	public void addNote(String note, Date date) throws ServiceException {
		// parameters validation
		if (note == null || "".equals(note)){
			throw new ServiceException("Wrong parameter!");
		}
		
				
		Note newNote = new Note();
		
		NoteBook noteBook = NoteBookProvider.getInstance().getNoteBook();
		// noteBook.add(newNote);
		
	}

}
